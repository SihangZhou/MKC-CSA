% In this version, both S and Si_s are constrained with inequality constraint

% Multiply sequence;
% Stop criterion: p_diff

clear
clc
warning off;


DataName = cell(13 , 1);
DataName{1} = 'bbcsport';
DataName{2} = 'bbcsport2view';
DataName{3} = 'proteinFold';
DataName{4} = 'caltech101_mit';
DataName{5} = 'CCV';
DataName{6} = 'flower17_DL_fea';
DataName{7} = 'mfeat';
DataName{8} = 'plant';
DataName{9} = 'psortPos';
DataName{10} = 'UCI_DIGIT';
DataName{11} = 'flower102';
DataName{12} = 'nonpl';
DataName{13} = 'flower17';


for ICount = [13]
    
    % Set path
    path = '../0_KernelProcessingandClustering';
    %pathdata = '/media/sihang/8ffb0279-b7eb-473a-b956-305a3b433e0c/Project/Kernel/datasets';
%     pathdata='/media/maggie/Data/papers/sh/datasets';
%     pathdata='E:\papers\sh\datasets';
%     pathdata='/Users/Maggie/Desktop/2020/dataset';
    pathdata='../dataset';
%     pathdata='/Volumes/Untitled/oqy拷数据/1202/datasets';
    addpath(genpath(path));
    dataName = DataName{ICount};
    load([pathdata,'/',dataName,'_Kmatrix'],'KH','Y');
    
    
    % Preprocessing
    CluNum = length(unique(Y));  % num of classes
    ker_num = size(KH,3); %num of views
    sample_num = size(KH,1);
    KH = kcenter(KH);
    KH = knorm(KH);
    f_num = CluNum * 4;
    H = zeros(f_num, sample_num, ker_num);
    
    opt.disp = 0;
    for p=1:ker_num % m - kernels
        KH(:,:,p) = (KH(:,:,p)+KH(:,:,p)')/2;
        [Hp, ~] = eigs(KH(:,:,p), f_num, 'la', opt);
        H(:,:,p) = Hp';
    end
    
    
    %%
    %%%%%%%%%%%%%%%%%%%  Proposed Method  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     H2 = zeros(size(KH));
%     for i = 1 : ker_num
%         H2(:,:,i) = H(:,:,i)' * H(:,:,i);
%     end
    
    p_num1 = max(50, CluNum*2);
    p_num2 = max(100, CluNum*4);
    parameters = [CluNum, p_num1, p_num2];
    
    %% Try different hyper-parameters
    for m_i = 1 : 3
%     for m_i = 1
        for alpha = 2.^[-15 : 2: 15]
%         for alpha = 2^[-5]
            tic;
            % parameters
            % m -- number of anchor points
%             m = round(sample_num / m_i);
            m = parameters(m_i);
            
            %% Initialization
            % Initialization of P, strategy 1, for large scale dataset
            P = randn(sample_num, m);
            P = orth(P);
            % Initialization of P, strategy 2
            %             [U, D, V] = svd((mean(H2, 3) + eye(size(H2, 1))));
            %             D = D(:, 1:m);
            %             P = U * (D~=0);
            
            % Initialization of S
            S = zeros(sample_num, m);
            S_record = zeros(sample_num, m, ker_num);
            
            % Initialization of Si
            for i = 1:ker_num
                % A = H2(:,:,i) * P;
                A = H(:,:,i)'*(H(:,:,i)*P);
%                 [Si] = qp(S, A, alpha);
                Si = (2 * alpha * S + A) / (2*alpha);
                Si(Si > 1) = 1;
                Si(Si < 0) = 0;
                S_record(:,:,i) = Si;
            end
            
            
            %% Optimization
            obj_record = [];
            it_count = 1;
            flag = 1;
            %while it_count < 20 || abs(obj_record(it_count) - obj_record(it_count-1))<10^(-5)
            while it_count < 50 && flag == 1
                %% Update P
                fprintf('it_count  %f\n', it_count);
                B = zeros(sample_num, m);
                for i = 1 : ker_num
%                     si = S_record(:,:,i);
                    % h2 = H2(:,:,i);
                    % B = B + h2 * si;
                    B = B + H(:,:,i)'*(H(:,:,i)*(S_record(:,:,i)+S));
                end
                % [U, D, V] = svd(B);
                [U, D, V] = svd(B, 'econ');
                % C = zeros(size(D));
                % for i = 1 : m
                %     C(i,i) = sign(D(i,i));
                % end
                % P = U * C * V';  % why named H_1
                %                 P_value = cal_obj(H2, P, S, S_record, alpha)
                P1 = U * V';
                p_diff = norm(P1-P, 'fro');
                P = P1;
                
                
                %% Update Si, namely S_record
                for i = 1:ker_num
                    % A = H2(:,:,i) * P;
                    A = H(:,:,i)'*(H(:,:,i)*P);
%                     [Si] = qp(S, A, alpha);
                    Si = (2 * alpha * S + A) / (2*alpha);
                    Si(Si > 1) = 1;
                    Si(Si < 0) = 0;
                    S_record(:,:,i) = Si;
                end
                %                 Si_Value = cal_obj(H2, P, S, S_record, alpha)
                
                
                %% Update S
                S = mean(S_record, 3);
%                 S(S < 0) = 0; %dont need this, as Si is satisfied.
%                 S(S > 1) = 1;
                %                 S_Value = cal_obj(H2, P, S, S_record, alpha)
                
                % objective value calculation
                it_count = it_count+1;
                % cur_obj = cal_obj(H2, P, S, S_record, alpha);
                % obj_record = [obj_record, cur_obj];
                
                % if it_count > 2 && abs((obj_record(it_count-1)-obj_record(it_count-2))/ obj_record(it_count-2)) < 10^(-4)
                %         flag = 0;
                % end
                if it_count > 2 && p_diff < 10^(-3)
                        flag = 0;
                end
            end
            
            % Result using S for the best
            %             labels=litekmeans(S, CluNum, 'MaxIter', 100,'Replicates',10); %kmeans(U, c, 'emptyaction', 'singleton', 'replicates', 100, 'display', 'off');
            %             result=ClusteringMeasure(labels,Y);
            %             fprintf('result  %f\n', result);
            
            res = myNMIACC(S,Y,CluNum);
            res_time = toc
            save(['./validate4time/', dataName, 'result', num2str(m_i),'_', num2str(log2(alpha)),'.mat'], ...
                 'res', 'obj_record','res_time')
        end
    end
end


%% The optimization process of Si
% min \alpha * ||S||_F^2  - 2 Tr((A+alpha * B)*S^T), s.t. 0<= S <=1
function [Si] = qp(A, B, alpha)
Si = (2 * alpha * A + B) / (2*alpha);
Si(Si > 1) = 1;
Si(Si < 0) = 0;
end


%% Calculate the objective function
function obj = cal_obj(H2, P, S, Si_s, alpha)
obj = 0;
ker_num = size(H2, 3);

%part 1
for i = 1 : ker_num
    obj = obj + trace(Si_s(:,:,i) * P' * H2(:,:,i));
end

obj = -obj;
% part 2
for i = 1 : ker_num
    obj = obj + alpha * norm(S-Si_s(:,:,i), 'fro')^2;
end

end
